#!/usr/bin/env python3
# -*- coding:utf8 -*-

import sys
sys.path.append("../")
from chat.upload import add_excel

if __name__ == "__main__":
    add_excel()
	