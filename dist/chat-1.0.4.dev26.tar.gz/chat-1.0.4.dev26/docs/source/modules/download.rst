API - 下载语义知识库
========================

.. image:: my_figs/packages.ico 
.. automodule:: chat.download

.. autosummary::

   match
   
匹配子图
------------------------
.. autofunction:: match
