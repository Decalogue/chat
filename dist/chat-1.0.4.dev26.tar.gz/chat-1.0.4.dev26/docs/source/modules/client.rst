API - 语义客户端
========================

.. image:: my_figs/client.ico 
.. automodule:: chat.client

.. autosummary::

   question_pack
   config_pack
   match
   config

封装问题
--------------
.. autofunction:: question_pack

封装配置
--------------
.. autofunction:: config_pack

搜索答案
--------------
.. autofunction:: match

配置语义知识库
------------------------
.. autofunction:: config