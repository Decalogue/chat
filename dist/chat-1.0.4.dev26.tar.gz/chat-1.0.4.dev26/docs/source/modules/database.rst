API - 语义数据库管理
========================

.. image:: my_figs/database.ico 
.. automodule:: chat.database

.. autosummary::

   Database
   
语义数据库管理
------------------------
.. autofunction:: Database
