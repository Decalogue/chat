API - 上传本地知识库
========================

.. image:: my_figs/packages.ico 
.. automodule:: chat.upload

.. autosummary::

   add_excel
   add_subgraph
   
上传excel文件
------------------------
.. autofunction:: add_excel

上传子图
------------------------
.. autofunction:: add_subgraph
