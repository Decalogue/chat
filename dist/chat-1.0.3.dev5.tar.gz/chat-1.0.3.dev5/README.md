# chat
`Natural Language Understanding based on Machine Learnings.`
`基于机器学习的自然语言理解`

[![Documentation Status](https://readthedocs.org/projects/chat-cn/badge/?version=latest)](http://chat-cn.readthedocs.io/zh_CN/latest/?badge=latest)

`Copyright © 2017 Rain. All Rights Reserved. `
[樱落清璃-Decalogue的CSDN博客](https://www.decalogue.cn)
