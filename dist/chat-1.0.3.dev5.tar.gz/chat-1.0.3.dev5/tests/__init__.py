#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Intelligent assistant Robot based on "Machine Learning."""

__author__ = "Rain"
__version__ = "1.0.3"
__license__ = "MIT"