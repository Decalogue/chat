.. _installation:

======================
安装 Installation
======================

Java开发环境
======================

jdk

图形数据库
======================

neo4j

Python3
======================

Anaconda

Python依赖包
-------------------

* chardet
* jieba
* numpy
* py2neo
* pynlpir
* requests
* xlrd
* xlwt
